package ch01;

public class Ex07 {
	public static void main(String[] args) {
		int hour = 3;
		int minute =5;
		System.out.println(hour+" 시간 "+minute +" 분 ");
		
		int totalMinute=(hour*60)+minute;
		System.out.println(totalMinute);
	}
}
