package ch01;

public class Ex01 {
	public static void main(String[] args) {
		System.out.println("안녕");
		//한줄주석
		/*
		 . : 알고있다, 가지고있다
		 ; : 실행문
		 	 문장의 마침표
		 클래스 이름 명명 규칙
		 	-겹치지 않게 사용
		 	-이름이 겹칠경우 구별할 것을 줘라(_ or 숫자 붙이기)
		 	-특수문자 _ $ 두가지만 사용 가능
		 	-첫글자에 숫자, 특수문자 오면 안됨
		 	-첫글자는 항상 대문자사용
		 	-단어의 조합은 첫글자 대문자로 (ex SportsScore)
		 실행 단축키 : Ctrl + F11
		 */
	}
}
